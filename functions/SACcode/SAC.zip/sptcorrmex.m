function [H, BC] = SPTCORRMEX(Spt1, Spt2, MaxLag, BinWidth)
%SPTCORRMEX spiketrain correlation (MEX implementation)
%  
%    This function is not intended for direct use, but is called by SPTCORR.
%
%    For details, see SPTCORR.

% Empty help file, shadowed by DLL.